<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Services\SupabaseService;

class AuthController extends Controller
{
    protected $supabaseService;

    public function __construct(SupabaseService $supabaseService)
    {
        $this->supabaseService = $supabaseService;
    }

    /**
     * API login: trả về access token nếu thành công
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        $loginValue = $request->email;
        if (filter_var($loginValue, FILTER_VALIDATE_EMAIL)) {
            $user = $this->supabaseService->getUserByEmail($loginValue);
        } else {
            $user = $this->supabaseService->getUserByUsername($loginValue);
        }
        if (!$user) {
            if ($request->wantsJson()) {
                return response()->json(['message' => 'Tài khoản không tồn tại!'], 401);
            }
            return redirect()->back()->with('error', 'Tài khoản không tồn tại!');
        }
        if (empty($user['is_admin']) || $user['is_admin'] !== true) {
            if ($request->wantsJson()) {
                return response()->json(['message' => 'Bạn không có quyền truy cập!'], 403);
            }
            return redirect()->back()->with('error', 'Bạn không có quyền truy cập!');
        }
        // Kiểm tra mật khẩu: so sánh md5
        $passwordValid = (md5($request->password) === $user['password']);
        if (!$passwordValid) {
            if ($request->wantsJson()) {
                return response()->json(['message' => 'Sai mật khẩu!'], 401);
            }
            return redirect()->back()->with('error', 'Sai mật khẩu!');
        }
        $token = base64_encode(\Str::random(40));
        session(['access_token' => $token, 'user' => $user]);
        session()->regenerate();
        if ($request->wantsJson()) {
            return response()->json([
                'access_token' => $token,
                'user' => [
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'is_admin' => $user['is_admin'],
                    'password' => $user['password'],
                ]
            ]);
        }
        return redirect('/');
    }

    /**
     * Đăng xuất
     */
    public function logout(Request $request)
    {
        session()->forget(['access_token', 'user']);
        return redirect('/login');
    }
}
