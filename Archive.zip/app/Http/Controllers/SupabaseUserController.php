<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SupabaseService;

class SupabaseUserController extends Controller
{
    protected $supabaseService;

    public function __construct(SupabaseService $supabaseService)
    {
        $this->supabaseService = $supabaseService;
    }

    /**
     * Lấy danh sách users từ Supabase
     */
    public function index(Request $request)
    {
        $params = $request->all();
        $users = $this->supabaseService->getUsers($params);
        return response()->json($users);
    }
}
