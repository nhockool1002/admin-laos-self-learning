<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        \Log::info('CheckAuth middleware đã chạy');
        dd(session('user'), session('access_token'));
        $user = session('user');
        $token = session('access_token');

        // Kiểm tra xem user đã login và có quyền admin chưa
        if (!$user || !$token || empty($user['is_admin']) || $user['is_admin'] !== true) {
            return redirect('/login');
        }
        
        return $next($request);
    }
}
