<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class SupabaseService
{
    protected $baseUrl;
    protected $apiKey;

    public function __construct()
    {
        $this->baseUrl = rtrim(env('APP_SUPABASE_URL'), '/') . '/rest/v1';
        $this->apiKey = env('APP_SUPABASE_ANON_KEY');
    }

    /**
     * Lấy danh sách users từ Supabase
     */
    public function getUsers($params = [])
    {
        $response = Http::withHeaders([
            'apikey' => $this->apiKey,
            'Authorization' => 'Bearer ' . $this->apiKey,
        ])->get($this->baseUrl . '/users', $params);

        if ($response->successful()) {
            return $response->json();
        }
        return null;
    }

    /**
     * Lấy user theo email từ Supabase
     */
    public function getUserByEmail($email)
    {
        $response = Http::withHeaders([
            'apikey' => $this->apiKey,
            'Authorization' => 'Bearer ' . $this->apiKey,
        ])->get($this->baseUrl . '/users', [
            'email' => 'eq.' . $email,
            'select' => '*',
        ]);

        if ($response->successful()) {
            $data = $response->json();
            return $data[0] ?? null;
        }
        return null;
    }

    /**
     * Lấy user theo username từ Supabase
     */
    public function getUserByUsername($username)
    {
        $response = Http::withHeaders([
            'apikey' => $this->apiKey,
            'Authorization' => 'Bearer ' . $this->apiKey,
        ])->get($this->baseUrl . '/users', [
            'username' => 'eq.' . $username,
            'select' => '*',
        ]);

        if ($response->successful()) {
            $data = $response->json();
            return $data[0] ?? null;
        }
        return null;
    }
} 