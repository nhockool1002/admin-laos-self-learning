<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SupabaseUserController;
use App\Http\Controllers\AuthController;

Route::get('/', function () {
    return view('admin');
})->name('panel')->middleware('auth');

Route::get('/supabase/users', [SupabaseUserController::class, 'index'])->middleware('auth');

Route::get('/login', function () {
    // Nếu đã login thì redirect về home
    $user = session('user');
    $token = session('access_token');
    if ($user && $token && !empty($user['is_admin']) && $user['is_admin'] === true) {
        return redirect('/');
    }
    return view('login');
})->name('login');
Route::post('/login', [AuthController::class, 'login']); // API login
Route::get('/logout', [AuthController::class, 'logout'])->middleware('auth');
